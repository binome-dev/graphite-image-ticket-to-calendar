import os
from typing import AsyncGenerator, List

from openinference.semconv.trace import OpenInferenceSpanKindValues
from pydantic import Field

from grafi.assistants.assistant import Assistant
from grafi.common.containers.container import event_store
from grafi.common.decorators.record_assistant_a_stream import record_assistant_a_stream
from grafi.common.events.topic_events.consume_from_topic_event import (
    ConsumeFromTopicEvent,
)
from grafi.common.models.execution_context import ExecutionContext
from grafi.common.models.message import Message
from grafi.common.topics.output_topic import agent_stream_output_topic
from grafi.common.topics.topic import agent_input_topic
from grafi.nodes.impl.llm_node import LLMNode
from grafi.tools.llms.impl.openai_tool import OpenAITool
from grafi.tools.llms.llm_stream_response_command import LLMStreamResponseCommand
from grafi.workflows.impl.event_driven_workflow import EventDrivenWorkflow


class SimpleStreamAssistant(Assistant):
    """
    A simple assistant class that uses OpenAI's language model to process input and generate responses.

    This class sets up a workflow with a single LLM node using OpenAI's API, and provides a method
    to run input through this workflow with token-by-token streaming.
    """

    oi_span_type: OpenInferenceSpanKindValues = Field(
        default=OpenInferenceSpanKindValues.AGENT
    )
    name: str = Field(default="SimpleStreamAssistant")
    type: str = Field(default="SimpleStreamAssistant")
    api_key: str = Field(default_factory=lambda: os.getenv("OPENAI_API_KEY"))
    system_message: str = Field(default=None)
    model: str = Field(default="gpt-4o-mini")

    workflow: EventDrivenWorkflow = None

    class Builder(Assistant.Builder):
        """Concrete builder for SimpleStreamAssistant."""

        def __init__(self):
            self._assistant = self._init_assistant()

        def _init_assistant(self) -> "SimpleStreamAssistant":
            return SimpleStreamAssistant()

        def api_key(self, api_key: str) -> "SimpleStreamAssistant.Builder":
            self._assistant.api_key = api_key
            return self

        def system_message(
            self, system_message: str
        ) -> "SimpleStreamAssistant.Builder":
            self._assistant.system_message = system_message
            return self

        def model(self, model: str) -> "SimpleStreamAssistant.Builder":
            self._assistant.model = model
            return self

        def build(self) -> "SimpleStreamAssistant":
            self._assistant._construct_workflow()
            return self._assistant

    def _construct_workflow(self) -> "SimpleStreamAssistant":
        """
        Build the underlying EventDrivenWorkflow with a single LLMStreamNode.
        """
        # Create an LLM node
        llm_node = (
            LLMNode.Builder()
            .name("LLMStreamNode")
            .subscribe(agent_input_topic)
            .command(
                LLMStreamResponseCommand.Builder()
                .llm(
                    OpenAITool.Builder()
                    .name("OpenAITool")
                    .api_key(self.api_key)
                    .model(self.model)
                    .system_message(self.system_message)
                    .build()
                )
                .build()
            )
            .publish_to(agent_stream_output_topic)
            .build()
        )

        # Create a workflow and add the LLM node
        self.workflow = (
            EventDrivenWorkflow.Builder()
            .name("SimpleLLMWorkflow")
            .node(llm_node)
            .build()
        )
        return self

    def execute(self, execution_context, input_data):
        raise ValueError(
            "This method is not supported for SimpleStreamAssistant. Use a_execute instead."
        )

    @record_assistant_a_stream
    async def a_execute(
        self, execution_context: ExecutionContext, input_data: List[Message]
    ) -> AsyncGenerator[Message, None]:
        """
        Execute the assistant's workflow with the provided input data and return the generated response.

        This method retrieves messages from memory based on the execution context, constructs the
        workflow, processes the input data through the workflow, and returns the combined content
        of the generated messages.

        Args:
            execution_context (ExecutionContext): The context in which the assistant is executed.
            input_data (str): The input string to be processed by the language model.

        Returns:
            str: The combined content of the generated messages, sorted by timestamp.
        """
        try:
            # Execute the workflow with the input data
            await self.workflow.a_execute(execution_context, input_data)

            consumed_event: ConsumeFromTopicEvent = self._get_consumed_events()

            output: AsyncGenerator[Message, None] = None
            if consumed_event:
                output = consumed_event.data

            return output
        finally:
            if consumed_event:
                event_store.record_event(consumed_event)

    def _get_consumed_events(self) -> ConsumeFromTopicEvent:
        consumed_event: ConsumeFromTopicEvent = None

        if agent_stream_output_topic.can_consume(self.name):
            event = agent_stream_output_topic.consume(self.name)[0]

            consumed_event = ConsumeFromTopicEvent(
                topic_name=event.topic_name,
                consumer_name=self.name,
                consumer_type=self.type,
                execution_context=event.execution_context,
                offset=event.offset,
                data=event.data,
            )

        return consumed_event
